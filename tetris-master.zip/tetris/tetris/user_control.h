#ifndef _USER_CONTROL_H_
#define _USER_CONTROL_H_

#include <stdio.h>
#include <termios.h>
#include <signal.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>

extern int getch();
extern void alarm_us(int n);
extern void key_control();
extern void fall_down();
extern int move_left(int n,int m);
extern int move_right(int n,int m);
extern int change_shape();
extern void game_over();
extern void recover_attribute();
#endif
