#include "user_control.h"
#include "user_print.h"

struct termios tm_old;

//获取一个字符，不回显
int getch()
{
        struct termios tm;
        //保存正常  输入属性 到 tm_old
        tcgetattr(0,&tm_old);
        //获取原始输入属性
        cfmakeraw(&tm);
        //设置原始输入属性
        tcsetattr(0,0,&tm);
        //不回显的获取一个字符
        int ch = getchar();
        //恢复正常输入属性
        tcsetattr(0,0,&tm_old);

        return ch;
}

void recover_attribute()
{
	//恢复正常输入属性
	tcsetattr(0,0,&tm_old);
}


//微秒定时器,当定时器启动后，每隔一段时间会发送SIGALRM信号
void alarm_us(int n)
{
	struct itimerval value;

	//设置定时器启动的初始化值n
	value.it_value.tv_sec = 0;
	value.it_value.tv_usec = n;

	//设置定时器启动后的间隔数
	value.it_interval.tv_sec = 0;
	value.it_interval.tv_usec = n;

	//1s后启动定时器，同时发出SIGALRM信号
	//每间隔5S发送一次SIGALRAM信号
	setitimer(ITIMER_REAL,&value,NULL);
}

void fall_down()
{
	int ret ;
	while(1)
	{
		//不断调用下降函数
		ret = move_down(dynamic_num,dynamic_mode);	
		if(ret == 1)
			return ;
	}
}

//int n = dynamic_num;
//int mode = dynamic_mode;
int move_left(int n,int m)
{
	//边界检测
	if(dynamic_x <= 12)
		return 1;

	//碰撞检测
	if(judge_shape(n,m,dynamic_x - 2,dynamic_y))
		return 1;

	erase_last_shape(n,m,dynamic_x,dynamic_y);
	dynamic_x -= 2;
	print_mode_shape(n,m,dynamic_x,dynamic_y,dynamic_color);
	return 0;
}

//int n = dynamic_num;
//int mode = dynamic_mode;
int move_right(int n,int m)
{
	//边界检测
	if(dynamic_x + 2 * (4 - shape[n][m][16]) - 1 >= 39)
		return 1;

	//碰撞检测
	if(judge_shape(n,m,dynamic_x + 2,dynamic_y))
		return 1;

	erase_last_shape(n,m,dynamic_x,dynamic_y);
	dynamic_x += 2;
	print_mode_shape(n,m,dynamic_x,dynamic_y,dynamic_color);
	return 0;
}

int change_shape()
{
	int m = (dynamic_mode + 1) % 4;

	//右侧越界判断
	if(dynamic_x + 2 * (4 - shape[dynamic_num][m][16]) - 1 > 39)
		return 1;

	//右侧越界判断
	if(dynamic_y + 2 * (4 - shape[dynamic_num][m][17]) - 1 > 29)
		return 1;

	erase_last_shape(dynamic_num,dynamic_mode,dynamic_x,dynamic_y);
	dynamic_mode = m;
	print_mode_shape(dynamic_num,dynamic_mode,dynamic_x,dynamic_y,dynamic_color);
}

void game_over()
{
	printf("\33[32;9H************ Game Over***********************************\33[0m");
	printf("\33[25h");
	printf("\n\n");
}

//^[[A
//^[ ESC \33
//[
//A
//B
//D
//C
void key_control()
{
	int ch;
	while(1)
	{
		ch = getch();	
		if(ch == 'q' ||ch == 'Q'){
			break;
		}else if(ch == '\r') {
			//图形直接到底
			fall_down();
		}else if(ch == '\33'){
			ch = getch();	
			if(ch == '[')	
			{
				ch = getch();	
				switch(ch)
				{
					case 'A': //上
						change_shape();
						break;
					case 'B': //下
						move_down(dynamic_num,dynamic_mode);
						break;
					case 'C': //右
						move_right(dynamic_num,dynamic_mode);
						break;
					case 'D': //左
						move_left(dynamic_num,dynamic_mode);
						break;
					default:
						break;
				}
			}
		}
	}
	game_over();
}
